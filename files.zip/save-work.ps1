# save-work.ps1
# Quick save — commits and pushes all current changes
# Run this anytime you want to save your progress

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Save Work — Commit & Push" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

Set-Location C:\AI-Agents

$status = git status --porcelain
if ($status) {
    # Show what changed
    Write-Host "Files changed:" -ForegroundColor Yellow
    git status --short
    Write-Host ""

    # Ask for commit message
    $msg = Read-Host "Commit message (or press Enter for auto-message)"
    
    if ([string]::IsNullOrWhiteSpace($msg)) {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm"
        $msg = "Work in progress — $timestamp"
    }

    git add .
    git commit -m $msg
    git push
    Write-Host ""
    Write-Host "[OK] Saved and pushed to GitHub." -ForegroundColor Green
} else {
    Write-Host "[OK] Nothing to save — working tree is clean." -ForegroundColor Green
}

Write-Host ""
