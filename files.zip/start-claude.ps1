# start-claude.ps1
# Safely commits any uncommitted work, then launches Claude Code with local Ollama
# This script ONLY creates a commit if there are changes — it won't break anything

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Claude Code (Local) — Quick Launcher" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Navigate to project
Set-Location C:\AI-Agents

# Check for uncommitted changes
$status = git status --porcelain
if ($status) {
    Write-Host "[!] You have uncommitted changes. Committing now..." -ForegroundColor Yellow
    Write-Host ""
    git add .
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm"
    git commit -m "Auto-save before Claude Code session — $timestamp"
    git push
    Write-Host ""
    Write-Host "[OK] Changes committed and pushed." -ForegroundColor Green
} else {
    Write-Host "[OK] Working tree is clean. No commit needed." -ForegroundColor Green
}

Write-Host ""
Write-Host "Launching Claude Code with local model (qwen3-coder-64k)..." -ForegroundColor Cyan
Write-Host "Type 'exit' or Ctrl+D to quit Claude Code when done." -ForegroundColor Gray
Write-Host ""

# Launch Claude Code pointed at local Ollama
claude --model qwen3-coder-64k
