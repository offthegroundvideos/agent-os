# start-codex.ps1
# Safely commits any uncommitted work before switching to Codex/ChatGPT
# This script ONLY creates a commit if there are changes — it won't break anything

Write-Host ""
Write-Host "========================================" -ForegroundColor Magenta
Write-Host "  Codex / ChatGPT — Switch Prep" -ForegroundColor Magenta
Write-Host "========================================" -ForegroundColor Magenta
Write-Host ""

# Navigate to project
Set-Location C:\AI-Agents

# Check for uncommitted changes
$status = git status --porcelain
if ($status) {
    Write-Host "[!] You have uncommitted changes. Committing now..." -ForegroundColor Yellow
    Write-Host ""
    git add .
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm"
    git commit -m "Auto-save before Codex session — $timestamp"
    git push
    Write-Host ""
    Write-Host "[OK] Changes committed and pushed." -ForegroundColor Green
} else {
    Write-Host "[OK] Working tree is clean. No commit needed." -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Ready to switch to Codex / ChatGPT" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Your code is committed and pushed to GitHub." -ForegroundColor Gray
Write-Host "Go ahead and open Codex — your project is safe." -ForegroundColor Gray
Write-Host ""
Write-Host "When you're done with Codex, run:" -ForegroundColor Gray
Write-Host "  .\start-claude.ps1" -ForegroundColor White
Write-Host "to switch back to Claude Code." -ForegroundColor Gray
Write-Host ""
